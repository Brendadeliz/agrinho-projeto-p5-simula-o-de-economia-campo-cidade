// --- VARIÁVEIS GLOBAIS ---
let larguraCampo, alimentos = [], dinheiroCampo = 100, ultimoGeracaoTempo = 0, TEMPO_PARA_NOVO_ALIMENTO = 2000;
let materiaPrimaIndoParaIndustria = [], produtosIndoParaMercado = [], totalProdutosNoMercado = 0;
let contadorMateriaPrimaNaIndustria = 0, QUANTIDADE_PARA_PRODUZIR = 3, LIMITE_PRODUTOS_VITORIA = 5;
let mensagemTemporaria = "", tempoMensagem = 0, jogoAcabou = false, animacoesDinheiro = [];

function setup() {
  createCanvas(800, 600);
  rectMode(CORNER);
  textAlign(CENTER, CENTER);
  textSize(12);
  larguraCampo = width / 2;
}

function draw() {
  if (jogoAcabou) {
    (totalProdutosNoMercado >= LIMITE_PRODUTOS_VITORIA) ? telaVitoria() : telaDerrota();
    return;
  }
  background(220);
  desenharAreasDoJogo();
  desenharLugaresFixos();
  gerarEVerAlimentos();
  gerenciarMovimentoDeItens();
  mostrarPlacar();
  mostrarMensagemTemporaria();
  gerenciarAnimacoesDinheiro();
  if (totalProdutosNoMercado >= LIMITE_PRODUTOS_VITORIA || dinheiroCampo <= 0) jogoAcabou = true;
}

// --- FUNÇÕES DE DESENHO DO CENÁRIO ---
function desenharAreasDoJogo() {
  fill(144, 238, 144); noStroke(); rect(0, 0, larguraCampo, height);
  fill(100); rect(larguraCampo, 0, width / 2, height);
  stroke(0); strokeWeight(2); line(larguraCampo, 0, larguraCampo, height);
}

function desenharLugaresFixos() {
  fill(139, 69, 19); rect(50, height / 2 + 50, larguraCampo - 100, height / 2 - 100);
  fill(0); textSize(16); text("Horta", larguraCampo / 2, height / 2 + 30);
  fill(255, 250, 205); rect(100, 100, 100, 80);
  fill(139, 0, 0); triangle(90, 100, 210, 100, 150, 50);
  fill(0); text("Casa Rural", 150, 200);
  fill(169, 169, 169); rect(width - 200, height / 2 - 50, 150, 100);
  fill(50); rect(width - 170, height / 2 - 100, 20, 50);
  fill(0); text("Indústria", width - 125, height / 2 + 70);
  textSize(18); text("MP: " + contadorMateriaPrimaNaIndustria + "/" + QUANTIDADE_PARA_PRODUZIR, width - 125, height / 2 - 120);
  fill(200, 200, 200); rect(width - 350, height - 150, 100, 80);
  fill(0); text("Mercado", width - 300, height - 165);
  textSize(18); text("Produtos: " + totalProdutosNoMercado, width - 300, height - 185);
}

// --- FUNÇÕES DE LÓGICA E ANIMAÇÃO ---
function gerarEVerAlimentos() {
  if (millis() - ultimoGeracaoTempo > TEMPO_PARA_NOVO_ALIMENTO) {
    let x = random(70, larguraCampo - 70);
    let y = random(height / 2 + 80, height - 80);
    let ehDestruicaoAmbiental = floor(random(2)) === 1;
    alimentos.push(new Alimento(x, y, ehDestruicaoAmbiental ? "Destr. Ambiental" : "M. Prima", ehDestruicaoAmbiental));
    ultimoGeracaoTempo = millis();
  }
  alimentos = alimentos.filter(a => !a.foiPego);
  alimentos.forEach(a => a.desenhar());
}

function gerenciarMovimentoDeItens() {
  for (let i = materiaPrimaIndoParaIndustria.length - 1; i >= 0; i--) {
    let item = materiaPrimaIndoParaIndustria[i];
    item.x += (width - 125 - item.x) * 0.03; item.y += (height / 2 - item.y) * 0.03;
    fill(0, 150, 0); ellipse(item.x, item.y, 20, 20);
    if (dist(item.x, item.y, width - 125, height / 2) < 20) {
      dinheiroCampo += 3; animacoesDinheiro.push({x: larguraCampo / 2, y: 30, valor: 3, cor: color(0, 150, 0), inicio: millis()});
      contadorMateriaPrimaNaIndustria++;
      if (contadorMateriaPrimaNaIndustria >= QUANTIDADE_PARA_PRODUZIR) {
        produtosIndoParaMercado.push({ x: width - 125, y: height / 2 }); contadorMateriaPrimaNaIndustria = 0;
      }
      materiaPrimaIndoParaIndustria.splice(i, 1);
    }
  }
  for (let i = produtosIndoParaMercado.length - 1; i >= 0; i--) {
    let produto = produtosIndoParaMercado[i];
    produto.x += ((width - 300) - produto.x) * 0.03; produto.y += ((height - 110) - produto.y) * 0.03;
    fill(255, 165, 0); rect(produto.x - 10, produto.y - 10, 20, 20);
    if (dist(produto.x, produto.y, width - 300, height - 110) < 20) {
      totalProdutosNoMercado++;
      TEMPO_PARA_NOVO_ALIMENTO = map(totalProdutosNoMercado, 0, LIMITE_PRODUTOS_VITORIA, 2000, 800);
      produtosIndoParaMercado.splice(i, 1);
    }
  }
}

function mostrarPlacar() {
  fill(0); textSize(24); text("Dinheiro do Campo: R$ " + dinheiroCampo, larguraCampo / 2, 30);
}

function mostrarMensagemTemporaria() {
  if (mensagemTemporaria !== "" && millis() < tempoMensagem + 2000) {
    push(); textAlign(CENTER, TOP); textSize(20); fill(255, 0, 0);
    text(mensagemTemporaria, width / 2, height / 2 - 50); pop();
  } else { mensagemTemporaria = ""; }
}

function gerenciarAnimacoesDinheiro() {
  // Controla a exibição e o desaparecimento das animações de dinheiro
  // (ex: "+3" ou "-10") que flutuam na tela por um curto período.
  for (let i = animacoesDinheiro.length - 1; i >= 0; i--) {
    let anim = animacoesDinheiro[i];
    let tempoDecorrido = millis() - anim.inicio;
    let duracao = 1000;
    if (tempoDecorrido < duracao) {
      let alpha = map(tempoDecorrido, 0, duracao, 255, 0);
      let yOffset = map(tempoDecorrido, 0, duracao, 0, -30);
      push(); fill(anim.cor, alpha); textSize(16); text("+" + anim.valor, anim.x, anim.y + yOffset); pop();
    } else { animacoesDinheiro.splice(i, 1); }
  }
}

// --- TELAS DE FIM DE JOGO E REINÍCIO ---
function telaVitoria() {
  background(50, 200, 50); fill(255); textSize(40); text("VOCÊ GANHOU!", width / 2, height / 2 - 80);
  textSize(24); text("Parabéns! Você entendeu a profunda relação:", width / 2, height / 2 - 20);
  text("O Campo produz, a Cidade transforma...", width / 2, height / 2 + 20);
  text("...e assim a **economia gira**!", width / 2, height / 2 + 60);
  fill(0, 100, 0); rect(width / 2 - 75, height / 2 + 100, 150, 50, 10);
  fill(255); textSize(20); text("JOGAR NOVAMENTE", width / 2, height / 2 + 125);
}

function telaDerrota() {
  background(200, 50, 50); fill(255); textSize(40); text("VOCÊ PERDEU!", width / 2, height / 2 - 50);
  textSize(24); text("O Campo precisa de sua atenção.", width / 2, height / 2 + 10);
  text("Cuide da matéria-prima para a economia girar!", width / 2, height / 2 + 40);
  fill(100, 0, 0); rect(width / 2 - 75, height / 2 + 100, 150, 50, 10);
  fill(255); textSize(20); text("TENTAR NOVAMENTE", width / 2, height / 2 + 125);
}

function reiniciarJogo() {
  dinheiroCampo = 100; alimentos = []; materiaPrimaIndoParaIndustria = []; produtosIndoParaMercado = [];
  totalProdutosNoMercado = 0; contadorMateriaPrimaNaIndustria = 0; ultimoGeracaoTempo = 0;
  TEMPO_PARA_NOVO_ALIMENTO = 2000; mensagemTemporaria = ""; tempoMensagem = 0;
  jogoAcabou = false; animacoesDinheiro = [];
}

// --- FUNÇÕES DE INTERAÇÃO ---
function mouseClicked() {
  if (jogoAcabou) {
    if (mouseX > width / 2 - 75 && mouseX < width / 2 + 75 && mouseY > height / 2 + 100 && mouseY < height / 2 + 150) {
      reiniciarJogo();
    }
    return;
  }
  for (let alimento of alimentos) {
    if (!alimento.foiPego && alimento.estaSobre(mouseX, mouseY)) {
      alimento.foiPego = true;
      if (!alimento.ehDestruicaoAmbiental) { materiaPrimaIndoParaIndustria.push({ x: alimento.x, y: alimento.y }); }
      else {
        dinheiroCampo -= 10; animacoesDinheiro.push({x: mouseX, y: mouseY, valor: -10, cor: color(255, 0, 0), inicio: millis()});
        mensagemTemporaria = "CUIDADO! Não pegue a Destruição Ambiental!"; tempoMensagem = millis();
      }
      break;
    }
  }
}

// --- CLASSE ALIMENTO ---
class Alimento {
  constructor(x, y, tipo, ehDestruicaoAmbiental) {
    this.x = x; this.y = y; this.tamanho = 40;
    this.tipo = tipo; this.ehDestruicaoAmbiental = ehDestruicaoAmbiental; this.foiPego = false;
  }
  desenhar() {
    if (this.ehDestruicaoAmbiental) {
      stroke(50, 50, 50); strokeWeight(4);
      line(this.x - this.tamanho / 2, this.y - this.tamanho / 2, this.x + this.tamanho / 2, this.y + this.tamanho / 2);
      line(this.x + this.tamanho / 2, this.y - this.tamanho / 2, this.x - this.tamanho / 2, this.y + this.tamanho / 2);
      noStroke(); fill(80, 80, 80, 150); ellipse(this.x, this.y, this.tamanho, this.tamanho);
    } else {
      fill(0, 180, 0); ellipse(this.x, this.y, this.tamanho * 0.7, this.tamanho * 0.7);
      fill(50, 100, 50); triangle(this.x, this.y - this.tamanho/2, this.x - this.tamanho/4, this.y, this.x + this.tamanho/4, this.y);
    }
    fill(255); textSize(12); text(this.tipo, this.x, this.y);
  }
  estaSobre(mx, my) { return dist(mx, my, this.x, this.y) < this.tamanho / 2; }
}